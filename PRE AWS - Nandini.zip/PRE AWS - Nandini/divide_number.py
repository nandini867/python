def divide_numbers():
    try:
        
        num1 = float(input("Enter the first number: "))
        
        
        num2 = float(input("Enter the second number: "))
        
        
        result = num1 / num2
        
        
        print(f"{num1} divided by {num2} is equal to {result}")
        
    except ValueError:
        print("Error: Please enter valid numbers.")
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    divide_numbers()
