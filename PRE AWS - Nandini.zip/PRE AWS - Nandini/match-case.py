#!/usr/bin/env python3.10

def main():
    while True:
        command = input("Enter command (start, stop, exit): ")
        
        match command:
            case 'start':
                print("Starting the process...")
            case 'stop':
                print("Stopping the process...")
            case 'exit':
                print("Exiting the program.")
                break
            case _:
                print("Invalid command. Please enter 'start', 'stop', or 'exit'.")

if __name__ == "__main__":
    main()
