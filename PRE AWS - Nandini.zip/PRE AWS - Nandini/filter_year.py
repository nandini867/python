import csv

def filter_sales_by_year(input_file, output_file, filter_year):
    try:
        with open(input_file, 'r', newline='') as csv_in_file:
            csv_reader = csv.reader(csv_in_file)
            header = next(csv_reader)  

        
            sale_id_index = header.index('sale_id')
            product_name_index = header.index('product_name')
            amount_index = header.index('amount')
            date_index = header.index('date')

            
            with open(output_file, 'w', newline='') as csv_out_file:
                csv_writer = csv.writer(csv_out_file)
                
                
                csv_writer.writerow(header)
                
                
                for row in csv_reader:
                    sale_id = row[sale_id_index]
                    product_name = row[product_name_index]
                    amount = float(row[amount_index])
                    date = row[date_index]

                    
                    year = int(date.split('-')[0])

                    
                    if year == filter_year:
                        csv_writer.writerow(row)
    
    except FileNotFoundError:
        print(f"Error: File '{input_file}' not found.")
    except ValueError:
        print(f"Error: Invalid year '{filter_year}'. Please enter a valid year (e.g., 2023).")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    input_file = input("Enter the input CSV file path: ").strip()
    output_file = input("Enter the output CSV file path: ").strip()
    filter_year = input("Enter the year to filter (e.g., 2023): ").strip()

    
    try:
        filter_year = int(filter_year)
    except ValueError:
        print("Error: Please enter a valid year.")
        exit()

    
    filter_sales_by_year(input_file, output_file, filter_year)
