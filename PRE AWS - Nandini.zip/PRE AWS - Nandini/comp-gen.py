
squares_list = [x**2 for x in range(1, 21)]

print("Using List Comprehension:")
print(squares_list)


squares_generator = (x**2 for x in range(1, 21))


print("\nUsing Generator Expression:")
for square in squares_generator:
    print(square)
