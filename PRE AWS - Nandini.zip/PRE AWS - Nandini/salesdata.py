from collections import defaultdict
from operator import itemgetter

def calculate_total_sales(sales_data):
    product_sales = defaultdict(lambda: {'product_name': '', 'quantity_sold': 0, 'revenue': 0.0})

    
    for sale in sales_data:
        product_id = sale['product_id']
        product_name = sale['product_name']
        quantity_sold = sale['quantity_sold']
        price_per_unit = sale['price_per_unit']

        
        revenue = quantity_sold * price_per_unit

        
        product_sales[product_id]['product_name'] = product_name
        product_sales[product_id]['quantity_sold'] += quantity_sold
        product_sales[product_id]['revenue'] += revenue

    
    sorted_products = sorted(product_sales.values(), key=itemgetter('revenue'), reverse=True)

    
    print("Total Sales per Product:")
    for index, product in enumerate(sorted_products, start=1):
        print(f"{index}. Product: {product['product_name']}, Total Sales: ${product['revenue']:.2f}, Quantity Sold: {product['quantity_sold']}")

if __name__ == "__main__":
    
    sales_data = [
        {'product_id': 'P1', 'product_name': 'Keyboard', 'quantity_sold': 100, 'price_per_unit': 20.5},
        {'product_id': 'P2', 'product_name': 'Mouse', 'quantity_sold': 150, 'price_per_unit': 15.75},
        {'product_id': 'P1', 'product_name': 'Keyboard', 'quantity_sold': 50, 'price_per_unit': 20.5},
        {'product_id': 'P3', 'product_name': 'Monitor', 'quantity_sold': 30, 'price_per_unit': 150.0},
        {'product_id': 'P2', 'product_name': 'Mouse', 'quantity_sold': 80, 'price_per_unit': 15.75},
    ]

    
    calculate_total_sales(sales_data)
