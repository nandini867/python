import datetime

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        raise ValueError("Division by zero error")
    return x / y

def calculator_operation(operation, x, y):
    operations = {
        'add': add,
        'subtract': subtract,
        'multiply': multiply,
        'divide': divide
    }
    
    if operation in operations:
        try:
            result = operations[operation](x, y)
            log_operation(operation, x, y, result)
            return result
        except Exception as e:
            log_error(operation, x, y, str(e))
            return f"Error: {str(e)}"
    else:
        log_error(operation, x, y, "Invalid operation")
        return "Error: Invalid operation"

def log_operation(operation, x, y, result):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {operation}({x}, {y}) = {result}\n"
    with open("error_log.txt", "a") as file:
        file.write(log_entry)

def log_error(operation, x, y, error_message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] ERROR during {operation}({x}, {y}): {error_message}\n"
    with open("error_log.txt", "a") as file:
        file.write(log_entry)

if __name__ == "__main__":
    print("Welcome to Simple Calculator!")

    while True:
        try:
            operation = input("Enter operation (add, subtract, multiply, divide) or 'exit' to quit: ")
            if operation == 'exit':
                break
            
            x = float(input("Enter first number: "))
            y = float(input("Enter second number: "))

            result = calculator_operation(operation, x, y)
            print(f"Result: {result}")
        
        except ValueError as ve:
            print(f"Error: {ve}. Please enter valid numbers.")
        except Exception as e:
            print(f"Error: {e}")

    print("Exiting Simple Calculator. See error_log.txt for operation logs.")
