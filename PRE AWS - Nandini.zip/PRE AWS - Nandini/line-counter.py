
#!/usr/bin/env python3

import sys

def count_lines(filename):
    try:
        with open(filename, 'r') as file:
            line_count = sum(1 for line in file)
        print(f"Number of lines in {filename}: {line_count}")
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
    except IsADirectoryError:
        print(f"Error: '{filename}' is a directory, not a file.")
    except IOError as e:
        print(f"Error: IOError occurred: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: ./line_counter.py <filename>")
    else:
        filename = sys.argv[1]
        count_lines(filename)
