import numpy as np

np.random.seed(0)  
temperatures = np.linspace(start=25.0, stop=40, num=100) + np.random.normal(loc=0, scale=0.2, size=100)

mean_temp = np.mean(temperatures)
median_temp = np.median(temperatures)
std_dev_temp = np.std(temperatures)
max_temp = np.max(temperatures)
min_temp = np.min(temperatures)

temp_diff = np.diff(temperatures)

avg_fluctuation = np.mean(np.abs(temp_diff))

print(f"Basic Statistics:")
print(f"Mean temperature: {mean_temp:.2f} °C")
print(f"Median temperature: {median_temp:.2f} °C")
print(f"Standard deviation of temperature: {std_dev_temp:.2f} °C")
print(f"Maximum temperature: {max_temp:.2f} °C")
print(f"Minimum temperature: {min_temp:.2f} °C")


print(f"\nTemperature Fluctuations:")
print(f"Day-to-day temperature differences:\n{temp_diff}")
print(f"Average day-to-day temperature fluctuation: {avg_fluctuation:.2f} °C")
