import os

def search_string_in_files(directory, search_string):
    try:
        if not os.path.isdir(directory):
            raise ValueError(f"Directory '{directory}' does not exist.")

        
        matching_files = []

        
        for filename in os.listdir(directory):
            if filename.endswith(".txt"):
                file_path = os.path.join(directory, filename)
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as file:
                        file_contents = file.read()
                        if search_string in file_contents:
                            matching_files.append(filename)
                except IOError as e:
                    print(f"Error reading file '{filename}': {e}")
        
        
        if matching_files:
            print(f"Files containing '{search_string}':")
            for file in matching_files:
                print(file)
        else:
            print(f"No files containing '{search_string}' found in {directory}")
    
    except ValueError as ve:
        print(f"Error: {ve}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    
    directory = input("Enter the directory path: ").strip()
    search_string = input("Enter the search string: ").strip()

    search_string_in_files(directory, search_string)
